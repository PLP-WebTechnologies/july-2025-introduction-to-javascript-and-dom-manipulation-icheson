// =======================
// Part 1: Variables & Conditionals
// =======================

function checkAge() {
  let age = document.getElementById("ageInput").value;
  let result = "";

  if (age >= 18) {
    result = "✅ You are an adult.";
  } else if (age > 0) {
    result = "❗ You are a minor.";
  } else {
    result = "❓ Please enter a valid age.";
  }

  document.getElementById("ageResult").textContent = result;
}

// =======================
// Part 2: Functions
// =======================

// Function 1: Calculate totals
function calculateTotal(a, b) {
  let total = a + b;
  document.getElementById("totalResult").textContent = `Total is: ${total}`;
}

// Function 2: Toggle content visibility
function toggleMessage() {
  let msg = document.getElementById("toggleText");
  msg.classList.toggle("hidden");
}

// =======================
// Part 3: Loops
// =======================

// Example 1: Countdown using a for loop
function showCountdown() {
  let text = "";
  for (let i = 5; i >= 1; i--) {
    text += i + "... ";
  }
  text += "🚀 Lift off!";
  document.getElementById("countdown").textContent = text;
}

// Example 2: Iterating through an array
function listFruits() {
  let fruits = ["🍎 Apple", "🍌 Banana", "🍊 Orange", "🍇 Grape"];
  let list = document.getElementById("fruitList");
  list.innerHTML = ""; // Clear existing list

  fruits.forEach(fruit => {
    let li = document.createElement("li");
    li.textContent = fruit;
    list.appendChild(li);
  });
}

// =======================
// Part 4: DOM Manipulation
// =======================

// Interaction 1: Change heading text
function changeHeading() {
  document.querySelector("h1").textContent = "🚀 JavaScript is Awesome!";
}

// Interaction 2: Add new item to list
function addNewItem() {
  let list = document.getElementById("dynamicList");
  let newItem = document.createElement("li");
  newItem.textContent = "New Dynamic Item";
  list.appendChild(newItem);
}

// Interaction 3: Toggle highlight class
function highlightSection() {
  document.getElementById("part4").classList.toggle("highlight");
}
